package ai.qeen.sdk

import android.content.Context
import android.net.Uri
import android.util.Log

/**
 * Qeen's provider-agnostic mobile analytics SDK.
 *
 * The public surface is deliberately small and boring so that the backing engine (today
 * PostHog, tomorrow possibly RudderStack) can change without any client code changing.
 * No engine type ever appears in this API.
 *
 * ```
 * QeenSDK.configure(context, apiKey = "...", host = "https://us.i.posthog.com", debug = true)
 * QeenSDK.identify("user_42", mapOf("email" to "a@b.com"))
 * QeenSDK.track("Add To Cart", mapOf("product_id" to "SKU-1001"))
 * QeenSDK.screen("Product")
 * QeenSDK.handleDeepLink(intent.data ?: Uri.EMPTY)
 * QeenSDK.flush()
 * QeenSDK.reset()
 * ```
 */
object QeenSDK {

    private const val TAG = "QeenSDK"

    private var provider: AnalyticsProvider? = null
    private var attribution: CampaignAttribution? = null
    private var debugLogging = false

    /**
     * Initialise the SDK. Call once, as early as possible (e.g. Application.onCreate).
     *
     * @param debug toggles branded `QeenSDK` logcat output. Off by default.
     * @param options advanced delivery settings, provisioned per workspace. Leave empty
     *   unless Qeen support has given you specific values.
     * @param collectInstallReferrer sends the install referrer (Google Play, and Meta when
     *   [metaAppId] is set) once per install as an `install:referrer` event. On by default.
     * @param metaAppId your Meta (Facebook) App ID. Enables the Meta Install Referrer,
     *   which attributes installs from Facebook / Instagram ads. Null skips Meta.
     */
    fun configure(
        context: Context,
        apiKey: String,
        host: String,
        debug: Boolean = false,
        options: Map<String, Any> = emptyMap(),
        collectInstallReferrer: Boolean = true,
        metaAppId: String? = null,
    ) {
        debugLogging = debug
        val engine = PostHogProvider()
        engine.configure(context, apiKey, host, options)
        provider = engine
        attribution = CampaignAttribution()
        log("configured · host=$host")

        if (collectInstallReferrer) {
            InstallReferrerTracker.start(context, metaAppId) { props ->
                engine.track(InstallReferrerTracker.EVENT, props)
            }
        }
    }

    fun identify(userId: String, traits: Map<String, Any>? = null) {
        val engine = provider ?: return warnNotConfigured("identify")
        log("identify · $userId")
        engine.identify(userId, traits)
    }

    fun track(event: String, properties: Map<String, Any>? = null) {
        val engine = provider ?: return warnNotConfigured("track")
        log("track · $event")
        engine.track(event, properties)
    }

    /**
     * Track one of the standard, typed events (added in 1.3.0). The event's wire name and
     * property map are derived from its type, so the CAPI payload is always well-shaped.
     * Legacy [track] with a freeform name + map is unchanged and still available.
     */
    fun track(event: QeenEvent) {
        val engine = provider ?: return warnNotConfigured("track")
        val name = event.wireName()
        log("track · $name")
        engine.track(name, event.properties())
    }

    // --- typed convenience helpers (thin wrappers over track(event)) ---

    fun productViewed(item: LineItem) = track(QeenEvent.ProductViewed(item))

    fun pageViewed(name: String? = null) = track(QeenEvent.PageViewed(pageName = name))

    fun wishlistAdd(item: LineItem) = track(QeenEvent.WishlistAdd(item))

    fun addToCart(cartId: String, item: LineItem, value: Money? = null, itemCount: Int? = null) =
        track(QeenEvent.AddToCart(cartId, item, value, itemCount))

    fun cartUpdated(cartId: String, value: Money? = null, itemCount: Int? = null) =
        track(QeenEvent.CartUpdated(cartId, value, itemCount))

    fun couponApplied(cartId: String, code: String) =
        track(QeenEvent.CouponApplied(cartId, code))

    fun couponRemoved(cartId: String, code: String) =
        track(QeenEvent.CouponRemoved(cartId, code))

    fun cartCleared(cartId: String) =
        track(QeenEvent.CartCleared(cartId))

    fun paymentMethodSet(cartId: String, method: String) =
        track(QeenEvent.PaymentMethodSet(cartId, method))

    fun shippingDetailsSet(cartId: String, method: String? = null) =
        track(QeenEvent.ShippingDetailsSet(cartId, method))

    fun checkoutStarted(
        cartId: String,
        value: Money? = null,
        itemCount: Int? = null,
        items: List<LineItem> = emptyList(),
        email: String? = null,
        phone: String? = null,
    ) = track(QeenEvent.CheckoutStarted(cartId, value, itemCount, items, email, phone))

    fun orderCompleted(
        orderId: String,
        cartId: String,
        value: Money? = null,
        items: List<LineItem> = emptyList(),
    ) = track(QeenEvent.OrderCompleted(orderId, cartId, value, items))

    fun orderPlaced(
        orderId: String,
        cartId: String,
        value: Money? = null,
        items: List<LineItem> = emptyList(),
    ) = track(QeenEvent.OrderPlaced(orderId, cartId, value, items))

    fun orderRefunded(
        orderId: String,
        value: Money? = null,
        items: List<LineItem> = emptyList(),
        refundId: String? = null,
        cartId: String? = null,
        reason: String? = null,
    ) = track(QeenEvent.OrderRefunded(orderId, value, items, refundId, cartId, reason))

    fun signedIn(method: String? = null, email: String? = null, phone: String? = null) =
        track(QeenEvent.SignedIn(method, email, phone))

    fun signedUp(method: String? = null, email: String? = null, phone: String? = null) =
        track(QeenEvent.SignedUp(method, email, phone))

    fun screen(name: String, properties: Map<String, Any>? = null) {
        val engine = provider ?: return warnNotConfigured("screen")
        log("screen · $name")
        engine.screen(name, properties)
    }

    /**
     * Feed every inbound deep link / app link here. Fires a "Deep Link Opened" event
     * carrying every query parameter on the link. Attribution (first/last-touch) is
     * derived server-side by Qeen.
     */
    fun handleDeepLink(uri: Uri) {
        val engine = provider ?: return warnNotConfigured("handleDeepLink")
        val attribution = attribution ?: return
        log("handleDeepLink · $uri")

        val eventProps = LinkedHashMap<String, Any>()
        eventProps["url"] = uri.toString()
        eventProps.putAll(attribution.allQueryParams(uri))
        engine.track("Deep Link Opened", eventProps)
    }

    /**
     * Re-reads the advertising id and ad-tracking choice, e.g. after the user changes
     * them in settings. configure() already reads them once.
     */
    fun refreshTrackingStatus() {
        if (provider == null) return warnNotConfigured("refreshTrackingStatus")
        log("refreshTrackingStatus")
        AdvertisingIdentity.refresh()
    }

    fun reset() {
        val engine = provider ?: return warnNotConfigured("reset")
        log("reset")
        engine.reset()
    }

    fun flush() {
        val engine = provider ?: return warnNotConfigured("flush")
        log("flush")
        engine.flush()
    }

    // --- internal ---

    internal fun log(message: String) {
        if (debugLogging) Log.d(TAG, message)
    }

    private fun warnNotConfigured(method: String) {
        Log.w(TAG, "$method ignored — configure() has not been called")
    }
}
