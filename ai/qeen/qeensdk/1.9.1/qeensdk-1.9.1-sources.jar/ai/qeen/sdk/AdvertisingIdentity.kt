package ai.qeen.sdk

import android.content.Context
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import java.util.concurrent.Executors

/**
 * Advertising-id fields added to every event, so ad platforms can match app events
 * (e.g. installs) to their ads: `advertising_id` (GAID) and `advertiser_tracking_enabled`.
 *
 * The Play services read blocks, so it runs on a background thread at configure().
 * Reads run one at a time, so an older read never overwrites a newer one. Events sent
 * before the first read finishes carry no advertising fields. Not persisted, so a
 * revoked id is never sent from a previous launch; a failed read clears the fields.
 *
 * No id is sent when the user limited ad tracking or deleted the id (all zeros); only
 * `advertiser_tracking_enabled = false` is. Nothing is sent when Play services is missing.
 */
internal object AdvertisingIdentity {

    const val ADVERTISING_ID_KEY = "advertising_id"
    const val TRACKING_ENABLED_KEY = "advertiser_tracking_enabled"

    // iOS-only keys; dropped here too so an app cannot send them from Android.
    private const val IDFV_KEY = "idfv"
    private const val ATT_STATUS_KEY = "att_status"
    val KEYS = setOf(ADVERTISING_ID_KEY, TRACKING_ENABLED_KEY, IDFV_KEY, ATT_STATUS_KEY)

    private const val ZERO_ID = "00000000-0000-0000-0000-000000000000"

    @Volatile private var cached: Map<String, Any> = emptyMap()
    @Volatile private var appContext: Context? = null
    private val reader = Executors.newSingleThreadExecutor { task ->
        Thread(task, "QeenSDK-advertising-id").apply { isDaemon = true }
    }

    /** The fields to add to an event right now. Never blocks. */
    fun current(): Map<String, Any> = cached

    /** Starts the background read. Call before the engine starts. */
    fun start(context: Context) {
        appContext = context.applicationContext
        refresh()
    }

    /** Re-reads the advertising id in the background. No-op before [start]. */
    fun refresh() {
        val app = appContext ?: return
        reader.execute { cached = read(app) }
    }

    private fun read(context: Context): Map<String, Any> = try {
        val info = AdvertisingIdClient.getAdvertisingIdInfo(context)
        val id = info.id?.takeIf { it.isNotBlank() && it != ZERO_ID }
        if (info.isLimitAdTrackingEnabled || id == null) {
            mapOf(TRACKING_ENABLED_KEY to false)
        } else {
            mapOf(ADVERTISING_ID_KEY to id, TRACKING_ENABLED_KEY to true)
        }
    } catch (e: Exception) {
        emptyMap()
    }
}
