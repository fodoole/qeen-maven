package ai.qeen.sdk

import android.net.Uri

/**
 * Parses inbound deep links for the `Deep Link Opened` event.
 *
 * The SDK's only job here is to capture EVERY query param from a deep link onto
 * the event — so a new marketing param never requires an SDK release to be seen.
 * First/last-touch attribution and stamping of subsequent events are handled by
 * the Qeen backend, NOT on-device.
 */
internal class CampaignAttribution {

    /** Extract EVERY query param from a deep link. Missing/empty values are omitted. */
    fun allQueryParams(uri: Uri): Map<String, String> {
        // getQueryParameter* throws on opaque (non-hierarchical) URIs — guard.
        val names = try {
            uri.queryParameterNames
        } catch (_: UnsupportedOperationException) {
            emptySet<String>()
        }
        val result = LinkedHashMap<String, String>()
        for (key in names) {
            uri.getQueryParameter(key)?.takeIf { it.isNotBlank() }?.let { result[key] = it }
        }
        return result
    }

    /** The attribution subset (`utm_*` + any `*clid` click id) of a link's query params. */
    fun parse(uri: Uri): Map<String, String> =
        allQueryParams(uri).filterKeys { isCampaignKey(it) }

    companion object {
        /**
         * True for params conventionally treated as attribution: any `utm_*` param, and
         * any click id ending in `clid` (`gclid`, `fbclid`, `ttclid`, `dclid`, …).
         * Pattern-based on purpose — future ad networks that follow the `*clid`
         * convention work with no code change.
         */
        fun isCampaignKey(name: String): Boolean =
            name.startsWith("utm_") || name.endsWith("clid")
    }
}
