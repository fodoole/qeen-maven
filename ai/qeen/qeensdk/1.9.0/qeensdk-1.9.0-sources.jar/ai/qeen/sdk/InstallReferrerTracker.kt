package ai.qeen.sdk

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import com.android.installreferrer.api.InstallReferrerClient
import com.android.installreferrer.api.InstallReferrerClient.InstallReferrerResponse
import com.android.installreferrer.api.InstallReferrerStateListener
import org.json.JSONObject
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Collects the install referrer once per install and sends it as an `install:referrer`
 * event, one per source:
 *   - Google Play Install Referrer (`source = google_play`).
 *   - Meta Install Referrer, read from the Facebook / Instagram / Facebook Lite apps'
 *     content providers (`source = facebook | instagram | facebook_lite`). Only when the
 *     client passed a Meta App ID.
 *
 * The SDK sends the raw referrer plus its parsed params. It does no attribution and no
 * decryption: Meta's `utm_content` is encrypted with the client's key, which never ships
 * in the app — the Qeen backend decrypts it and decides first-touch.
 *
 * Must never affect the host app: all work runs on a private background thread and every
 * step is wrapped in `catch (Throwable)`. A failure leaves the "done" flag unset, so the
 * next launch retries.
 */
internal object InstallReferrerTracker {

    const val EVENT = "install:referrer"

    private const val PREFS = "ai.qeen.sdk.prefs"
    private const val KEY_PLAY_DONE = "qeen_install_referrer_play_done"
    private const val KEY_META_DONE = "qeen_install_referrer_meta_done"

    private val META_PROVIDERS = listOf(
        "facebook" to "content://com.facebook.katana.provider.InstallReferrerProvider/",
        "instagram" to "content://com.instagram.contentprovider.InstallReferrerProvider/",
        "facebook_lite" to "content://com.facebook.lite.provider.InstallReferrerProvider/",
    )

    private val started = AtomicBoolean(false)

    private val executor: ExecutorService by lazy {
        Executors.newSingleThreadExecutor { r ->
            Thread(r, "QeenSDK-referrer").apply { isDaemon = true }
        }
    }

    /**
     * Starts collection. Runs at most once per process; each source sends at most once
     * per install. [send] delivers the event; [isOptedOut] is checked before sending so
     * an opted-out user's referrer is kept for later rather than dropped.
     */
    fun start(
        context: Context,
        metaAppId: String?,
        send: (Map<String, Any>) -> Unit,
        isOptedOut: () -> Boolean,
    ) {
        try {
            if (!started.compareAndSet(false, true)) return
            val app = context.applicationContext
            val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (!prefs.getBoolean(KEY_PLAY_DONE, false)) fetchPlay(app, prefs, send, isOptedOut)
            val appId = metaAppId?.trim().orEmpty()
            if (appId.isNotEmpty() && !prefs.getBoolean(KEY_META_DONE, false)) {
                executor.execute { safely { fetchMeta(app, appId, prefs, send, isOptedOut) } }
            }
        } catch (t: Throwable) {
            QeenSDK.log("install referrer · start failed: $t")
        }
    }

    // --- Google Play ---

    private fun fetchPlay(
        context: Context,
        prefs: SharedPreferences,
        send: (Map<String, Any>) -> Unit,
        isOptedOut: () -> Boolean,
    ) {
        val client = InstallReferrerClient.newBuilder(context).build()
        client.startConnection(object : InstallReferrerStateListener {
            override fun onInstallReferrerSetupFinished(code: Int) {
                // Callback runs on the main thread; the binder call below must not.
                executor.execute {
                    safely {
                        try {
                            handlePlayResult(client, code, prefs, send, isOptedOut)
                        } finally {
                            safely { client.endConnection() }
                        }
                    }
                }
            }

            // Retried on next launch (flag still unset).
            override fun onInstallReferrerServiceDisconnected() {}
        })
    }

    private fun handlePlayResult(
        client: InstallReferrerClient,
        code: Int,
        prefs: SharedPreferences,
        send: (Map<String, Any>) -> Unit,
        isOptedOut: () -> Boolean,
    ) {
        when (code) {
            InstallReferrerResponse.OK -> {
                if (isOptedOut()) return
                val details = client.installReferrer
                val raw = details.installReferrer.orEmpty()
                val props = LinkedHashMap<String, Any>()
                props.putAll(parseQuery(raw))
                props["source"] = "google_play"
                props["referrer"] = raw
                props["referrer_click_ts"] = details.referrerClickTimestampSeconds
                props["install_begin_ts"] = details.installBeginTimestampSeconds
                details.installVersion?.let { props["install_version"] = it }
                props["google_play_instant"] = details.googlePlayInstantParam
                send(props)
                markDone(prefs, KEY_PLAY_DONE)
                QeenSDK.log("install referrer · google_play sent")
            }
            // Not a Play install / no Play Store: nothing to collect, ever.
            InstallReferrerResponse.FEATURE_NOT_SUPPORTED,
            InstallReferrerResponse.DEVELOPER_ERROR -> {
                markDone(prefs, KEY_PLAY_DONE)
                QeenSDK.log("install referrer · google_play unavailable (code $code)")
            }
            // SERVICE_UNAVAILABLE, SERVICE_DISCONNECTED, etc.: retry next launch.
            else -> QeenSDK.log("install referrer · google_play retry later (code $code)")
        }
    }

    // --- Meta ---

    private fun fetchMeta(
        context: Context,
        appId: String,
        prefs: SharedPreferences,
        send: (Map<String, Any>) -> Unit,
        isOptedOut: () -> Boolean,
    ) {
        if (isOptedOut()) return
        for ((source, base) in META_PROVIDERS) {
            val row = safely { queryMeta(context, Uri.parse(base + appId)) } ?: continue
            val props = LinkedHashMap<String, Any>()
            props.putAll(parseJson(row.referrer))
            props["source"] = source
            props["referrer"] = row.referrer
            row.isClickThrough?.let { props["is_click_through"] = it }
            row.timestamp?.let { props["referrer_click_ts"] = it }
            send(props)
            QeenSDK.log("install referrer · $source sent")
        }
        // Done once every provider was asked, whether or not any had data: the Meta
        // apps keep the referrer from the ad click, so a later query adds nothing.
        markDone(prefs, KEY_META_DONE)
    }

    private class MetaRow(val referrer: String, val isClickThrough: Boolean?, val timestamp: Long?)

    /** One provider's referrer, or null when the app is absent or has none for us. */
    private fun queryMeta(context: Context, uri: Uri): MetaRow? {
        val projection = arrayOf("install_referrer", "is_ct", "actual_timestamp")
        context.contentResolver.query(uri, projection, null, null, null)?.use { c ->
            if (!c.moveToFirst()) return null
            val refIdx = c.getColumnIndex("install_referrer")
            if (refIdx < 0 || c.isNull(refIdx)) return null
            val referrer = c.getString(refIdx)?.takeIf { it.isNotBlank() } ?: return null
            val ctIdx = c.getColumnIndex("is_ct")
            val tsIdx = c.getColumnIndex("actual_timestamp")
            return MetaRow(
                referrer = referrer,
                isClickThrough = if (ctIdx >= 0 && !c.isNull(ctIdx)) c.getInt(ctIdx) == 1 else null,
                timestamp = if (tsIdx >= 0 && !c.isNull(tsIdx)) c.getLong(tsIdx) else null,
            )
        }
        return null
    }

    // --- helpers ---

    /** Params of a Play referrer (`utm_source=x&utm_medium=y`), via the deep-link parser. */
    private fun parseQuery(raw: String): Map<String, String> =
        if (raw.isBlank()) emptyMap()
        else CampaignAttribution().allQueryParams(Uri.parse("qeen://referrer?$raw"))

    /** Top-level fields of Meta's JSON referrer; nested objects (e.g. encrypted
     *  `utm_content`) are kept as JSON strings for the backend to decrypt. */
    private fun parseJson(raw: String): Map<String, Any> = try {
        val json = JSONObject(raw)
        val result = LinkedHashMap<String, Any>()
        for (key in json.keys()) {
            when (val value = json.opt(key)) {
                null, JSONObject.NULL -> Unit
                is String, is Number, is Boolean -> result[key] = value
                else -> result[key] = value.toString()
            }
        }
        result
    } catch (_: Throwable) {
        emptyMap()
    }

    private fun markDone(prefs: SharedPreferences, key: String) {
        prefs.edit().putBoolean(key, true).apply()
    }

    private inline fun <T> safely(block: () -> T): T? = try {
        block()
    } catch (t: Throwable) {
        QeenSDK.log("install referrer · failed: $t")
        null
    }
}
