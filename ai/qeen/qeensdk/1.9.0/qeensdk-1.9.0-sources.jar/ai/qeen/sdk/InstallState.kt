package ai.qeen.sdk

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

/**
 * Install fields added to every event: `PackageInfo.firstInstallTime` and
 * `lastUpdateTime`, epoch ms. Read once at configure().
 *
 * Deliberately vendor-free: [PostHogProvider] attaches them to events.
 */
internal object InstallState {

    const val FIRST_INSTALL_TIME_KEY = "qeen_first_install_time"
    const val LAST_UPDATE_TIME_KEY = "qeen_last_update_time"

    /** The install fields, or empty when package info cannot be read. Never throws. */
    fun read(context: Context): Map<String, Any> = try {
        val info = packageInfo(context)
        mapOf(
            FIRST_INSTALL_TIME_KEY to info.firstInstallTime,
            LAST_UPDATE_TIME_KEY to info.lastUpdateTime,
        )
    } catch (e: Exception) {
        emptyMap()
    }

    private fun packageInfo(context: Context): PackageInfo {
        val pm = context.packageManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageInfo(context.packageName, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(context.packageName, 0)
        }
    }
}
