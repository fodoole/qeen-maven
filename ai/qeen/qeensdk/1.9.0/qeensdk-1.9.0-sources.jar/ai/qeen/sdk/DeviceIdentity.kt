package ai.qeen.sdk

import android.content.Context
import java.util.UUID

/**
 * Stable, per-install device identifier — generated once and persisted.
 *
 * Engine-independent on purpose: it vends a plain [String] and knows nothing about
 * PostHog. It is stamped on every event as the `qeen_device_id` super property so
 * device continuity survives `identify` / `reset` (login/logout), which otherwise
 * rotate the engine's own anonymous id.
 *
 * Storage is [android.content.SharedPreferences] by deliberate choice:
 *   - It survives process restarts and login/logout (the continuity we want).
 *   - It is cleared on app uninstall, so a reinstall gets a FRESH id. We avoid any
 *     OS/advertising identifier (ANDROID_ID, GAID): those are permission- and
 *     policy-encumbered, user-resettable/zeroable, and heavier to disclose. A
 *     self-generated UUID is the modern best practice and fully under our control.
 */
internal object DeviceIdentity {

    private const val PREFS = "ai.qeen.sdk.prefs"
    private const val KEY = "qeen_device_id"

    /** The current device id, creating and persisting one on first access. */
    fun current(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.getString(KEY, null)?.takeIf { it.isNotEmpty() }?.let { return it }
        val generated = UUID.randomUUID().toString()
        prefs.edit().putString(KEY, generated).apply()
        return generated
    }
}
