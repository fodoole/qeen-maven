package ai.qeen.sdk

import android.content.Context
import android.net.Uri

/**
 * Parses inbound deep links for campaign attribution and turns them into super properties.
 *
 * - **First-touch** is captured once and kept **permanently** (SharedPreferences), exposed
 *   under `initial_*` keys — the campaign that first acquired this install.
 * - **Last-touch** lives for the **process session** only (in memory), exposed under the
 *   canonical `utm_*` keys — the most recent campaign this session.
 *
 * Both sets are registered as PostHog super properties so they attach to every subsequent
 * event automatically.
 */
internal class CampaignAttribution(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // Last-touch is per-session: reset every cold start, matching the iOS twin.
    private var lastTouch: Map<String, String> = emptyMap()

    /** Extracts the recognised campaign parameters from a deep link, in canonical order. */
    fun parse(uri: Uri): Map<String, String> {
        // getQueryParameter* throws on opaque (non-hierarchical) URIs — guard.
        val names = try {
            uri.queryParameterNames
        } catch (_: UnsupportedOperationException) {
            emptySet<String>()
        }
        val result = LinkedHashMap<String, String>()
        for (key in CAMPAIGN_KEYS) {
            if (key in names) {
                uri.getQueryParameter(key)?.takeIf { it.isNotBlank() }?.let { result[key] = it }
            }
        }
        return result
    }

    /** Records a touch: sets session last-touch, and first-touch once (permanent). */
    fun record(params: Map<String, String>) {
        if (params.isEmpty()) return
        lastTouch = params
        if (!prefs.getBoolean(FIRST_TOUCH_MARKER, false)) {
            prefs.edit().apply {
                putBoolean(FIRST_TOUCH_MARKER, true)
                for ((k, v) in params) putString(firstTouchKey(k), v)
            }.apply()
        }
    }

    /** Canonical last-touch (`utm_*`) + first-touch (`initial_utm_*`) as super properties. */
    fun superProperties(): Map<String, Any> {
        val out = LinkedHashMap<String, Any>()
        for ((k, v) in lastTouch) out[k] = v
        for (k in CAMPAIGN_KEYS) {
            prefs.getString(firstTouchKey(k), null)?.let { out["initial_$k"] = it }
        }
        return out
    }

    private fun firstTouchKey(key: String) = "firstTouch.$key"

    companion object {
        private const val PREFS = "ai.qeen.sdk.attribution"
        private const val FIRST_TOUCH_MARKER = "firstTouch.__set"
        private val CAMPAIGN_KEYS = listOf(
            "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
            "gclid", "fbclid",
        )
    }
}
