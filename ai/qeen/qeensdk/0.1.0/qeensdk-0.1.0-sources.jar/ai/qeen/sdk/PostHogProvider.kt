package ai.qeen.sdk

import android.content.Context
import com.posthog.PostHog
import com.posthog.android.PostHogAndroid
import com.posthog.android.PostHogAndroidConfig

/**
 * PostHog-backed engine. THIS IS THE ONLY FILE THAT IMPORTS PostHog.
 *
 * To add the RudderStack twin later, create a `RudderStackProvider` next to this file
 * that also implements [AnalyticsProvider] and flip the one line in `QeenSDK.configure`.
 * Nothing else — including the client app — moves.
 *
 * API verified against PostHog Android SDK 3.19.0:
 *   - PostHogAndroid.setup(context, PostHogAndroidConfig(apiKey, host))
 *   - PostHog.capture(event, properties=), identify(distinctId, userProperties=)
 *   - PostHog.screen(title, properties=), register(key, value), reset(), flush()
 */
internal class PostHogProvider : AnalyticsProvider {

    override fun configure(context: Context, apiKey: String, host: String) {
        val config = PostHogAndroidConfig(apiKey = apiKey, host = host).apply {
            // AUTO EVENTS: let PostHog capture what it can on its own.
            captureApplicationLifecycleEvents = true // app installed/updated/opened/backgrounded
            captureScreenViews = true                // Activity-level screen autocapture

            // We own deep-link attribution and fire our own branded "Deep Link Opened"
            // event (with parsed UTM), so PostHog's built-in deep-link capture is off to
            // avoid a duplicate, un-enriched event.
            captureDeepLinks = false

            // Feature flags: not used by this SDK. Turning both off stops the flags /
            // remote-config network calls (and the "$feature_flag_called" events).
            sendFeatureFlagEvent = false
            preloadFeatureFlags = false

            // Engine-level debug logging stays OFF: the noisy PostHog logcat output is an
            // internal detail. QeenSDK does its own branded logging via configure(debug=).
            debug = false
        }
        // applicationContext: never hold an Activity — the SDK outlives any screen.
        PostHogAndroid.setup(context.applicationContext, config)
    }

    override fun identify(userId: String, traits: Map<String, Any>?) {
        PostHog.identify(userId, userProperties = traits)
    }

    override fun track(event: String, properties: Map<String, Any>?) {
        PostHog.capture(event, properties = properties)
    }

    override fun screen(name: String, properties: Map<String, Any>?) {
        PostHog.screen(name, properties = properties)
    }

    override fun registerSuperProperties(properties: Map<String, Any>) {
        // PostHog persists these and attaches them to every future event.
        // register() takes one key/value at a time (no map overload).
        for ((key, value) in properties) PostHog.register(key, value)
    }

    override fun reset() {
        PostHog.reset()
    }

    override fun flush() {
        PostHog.flush()
    }
}
