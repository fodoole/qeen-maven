package ai.qeen.sdk

import android.content.Context

/**
 * The engine contract QeenSDK talks to. Intentionally generic and `internal` — it is
 * never part of the public API, so the backing analytics vendor stays an implementation
 * detail. Today the only implementation is [PostHogProvider]; a future RudderStack twin
 * would be a second implementation of exactly this interface.
 */
internal interface AnalyticsProvider {
    fun configure(context: Context, apiKey: String, host: String)
    fun identify(userId: String, traits: Map<String, Any>?)
    fun track(event: String, properties: Map<String, Any>?)
    fun screen(name: String, properties: Map<String, Any>?)
    fun registerSuperProperties(properties: Map<String, Any>)
    fun reset()
    fun flush()
}
