package ai.qeen.sdk

import android.content.Context
import com.posthog.PersonProfiles
import com.posthog.PostHog
import com.posthog.PostHogEncryption
import com.posthog.PostHogOnFeatureFlags
import com.posthog.PostHogPropertiesSanitizer
import com.posthog.android.PostHogAndroid
import com.posthog.android.PostHogAndroidConfig
import java.io.InputStream
import java.io.OutputStream
import java.net.Proxy
import java.util.UUID

/**
 * PostHog-backed engine. THIS IS THE ONLY FILE THAT IMPORTS PostHog.
 *
 * To add the RudderStack twin later, create a `RudderStackProvider` next to this file
 * that also implements [AnalyticsProvider] and flip the one line in `QeenSDK.configure`.
 * Nothing else — including the client app — moves.
 *
 * API verified against PostHog Android SDK 3.19.0:
 *   - PostHogAndroid.setup(context, PostHogAndroidConfig(apiKey, host))
 *   - PostHog.capture(event, properties=), identify(distinctId, userProperties=)
 *   - PostHog.screen(title, properties=), register(key, value), reset(), flush()
 */
internal class PostHogProvider : AnalyticsProvider {

    override fun configure(context: Context, apiKey: String, host: String, options: Map<String, Any>) {
        val config = PostHogAndroidConfig(apiKey = apiKey, host = host).apply {
            // AUTO EVENTS: let PostHog capture what it can on its own.
            captureApplicationLifecycleEvents = true // app installed/updated/opened/backgrounded
            captureScreenViews = true                // Activity-level screen autocapture

            // We own deep-link attribution and fire our own branded "Deep Link Opened"
            // event (with parsed UTM), so PostHog's built-in deep-link capture is off to
            // avoid a duplicate, un-enriched event.
            captureDeepLinks = false

            // Feature flags: not used by this SDK. Turning both off stops the flags /
            // remote-config network calls (and the "$feature_flag_called" events).
            sendFeatureFlagEvent = false
            preloadFeatureFlags = false

            // Engine-level debug logging stays OFF: the noisy PostHog logcat output is an
            // internal detail. QeenSDK does its own branded logging via configure(debug=).
            debug = false
        }
        // Per-workspace overrides applied last so they win over the defaults above.
        applyOverrides(config, options)
        // applicationContext: never hold an Activity — the SDK outlives any screen.
        PostHogAndroid.setup(context.applicationContext, config)
    }

    /**
     * Applies advanced engine settings supplied at configure() time. Covers every
     * primitive-valued setting the engine config exposes, plus its function/object hooks
     * via neutral (vendor-free) signatures adapted internally. Values arrive as a neutral
     * key/value map; unknown keys and type mismatches are ignored (forward-compatible).
     */
    @Suppress("UNCHECKED_CAST")
    private fun applyOverrides(config: PostHogAndroidConfig, options: Map<String, Any>) {
        for ((key, value) in options) {
            when (key) {
                // delivery / batching
                "flushAt" -> (value as? Number)?.let { config.flushAt = it.toInt() }
                "flushIntervalSeconds" -> (value as? Number)?.let { config.flushIntervalSeconds = it.toInt() }
                "maxQueueSize" -> (value as? Number)?.let { config.maxQueueSize = it.toInt() }
                "maxBatchSize" -> (value as? Number)?.let { config.maxBatchSize = it.toInt() }
                // automatic capture
                "captureApplicationLifecycleEvents" -> (value as? Boolean)?.let { config.captureApplicationLifecycleEvents = it }
                "captureScreenViews" -> (value as? Boolean)?.let { config.captureScreenViews = it }
                "captureDeepLinks" -> (value as? Boolean)?.let { config.captureDeepLinks = it }
                // feature flags / remote config
                "sendFeatureFlagEvent" -> (value as? Boolean)?.let { config.sendFeatureFlagEvent = it }
                "preloadFeatureFlags" -> (value as? Boolean)?.let { config.preloadFeatureFlags = it }
                "remoteConfig" -> (value as? Boolean)?.let { config.remoteConfig = it }
                // privacy / identity / misc
                "optOut" -> (value as? Boolean)?.let { config.optOut = it }
                "sessionReplay" -> (value as? Boolean)?.let { config.sessionReplay = it }
                "reuseAnonymousId" -> (value as? Boolean)?.let { config.reuseAnonymousId = it }
                "debug" -> (value as? Boolean)?.let { config.debug = it }
                "personProfiles" -> (value as? String)?.let {
                    when (it.lowercase()) {
                        "always" -> config.personProfiles = PersonProfiles.ALWAYS
                        "identified_only", "identifiedonly" -> config.personProfiles = PersonProfiles.IDENTIFIED_ONLY
                        "never" -> config.personProfiles = PersonProfiles.NEVER
                    }
                }
                // function / object hooks — accepted as neutral values, adapted internally.
                "getAnonymousId" -> (value as? (UUID) -> UUID)?.let { config.getAnonymousId = it }
                "propertiesSanitizer" -> (value as? (Map<String, Any>) -> Map<String, Any>)?.let { fn ->
                    config.propertiesSanitizer = PostHogPropertiesSanitizer { props -> fn(props) }
                }
                "onFeatureFlags" -> (value as? () -> Unit)?.let { fn ->
                    config.onFeatureFlags = PostHogOnFeatureFlags { fn() }
                }
                "proxy" -> (value as? Proxy)?.let { config.proxy = it }
                "sessionReplayConfig" -> (value as? Map<String, Any>)?.let { m ->
                    val rc = config.sessionReplayConfig
                    (m["maskAllTextInputs"] as? Boolean)?.let { rc.maskAllTextInputs = it }
                    (m["maskAllImages"] as? Boolean)?.let { rc.maskAllImages = it }
                    (m["captureLogcat"] as? Boolean)?.let { rc.captureLogcat = it }
                    (m["screenshot"] as? Boolean)?.let { rc.screenshot = it }
                    (m["debouncerDelayMs"] as? Number)?.let { rc.debouncerDelayMs = it.toLong() }
                    (m["throttleDelayMs"] as? Number)?.let { rc.throttleDelayMs = it.toLong() }
                }
            }
        }
        // Encryption is a pair of stream transforms — supply both `encrypt` and `decrypt`
        // as closures over the standard java.io streams (no vendor types involved).
        val enc = options["encrypt"] as? (OutputStream) -> OutputStream
        val dec = options["decrypt"] as? (InputStream) -> InputStream
        if (enc != null && dec != null) {
            config.encryption = object : PostHogEncryption {
                override fun encrypt(outputStream: OutputStream): OutputStream = enc(outputStream)
                override fun decrypt(inputStream: InputStream): InputStream = dec(inputStream)
            }
        }
    }

    override fun identify(userId: String, traits: Map<String, Any>?) {
        PostHog.identify(userId, userProperties = traits)
    }

    override fun track(event: String, properties: Map<String, Any>?) {
        PostHog.capture(event, properties = properties)
    }

    override fun screen(name: String, properties: Map<String, Any>?) {
        PostHog.screen(name, properties = properties)
    }

    override fun reset() {
        PostHog.reset()
    }

    override fun flush() {
        PostHog.flush()
    }
}
