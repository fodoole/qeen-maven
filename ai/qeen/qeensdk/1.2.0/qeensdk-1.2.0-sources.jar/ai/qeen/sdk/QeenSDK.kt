package ai.qeen.sdk

import android.content.Context
import android.net.Uri
import android.util.Log

/**
 * Qeen's provider-agnostic mobile analytics SDK.
 *
 * The public surface is deliberately small and boring so that the backing engine (today
 * PostHog, tomorrow possibly RudderStack) can change without any client code changing.
 * No engine type ever appears in this API.
 *
 * ```
 * QeenSDK.configure(context, apiKey = "...", host = "https://us.i.posthog.com", debug = true)
 * QeenSDK.identify("user_42", mapOf("email" to "a@b.com"))
 * QeenSDK.track("Add To Cart", mapOf("product_id" to "SKU-1001"))
 * QeenSDK.screen("Product")
 * QeenSDK.handleDeepLink(intent.data ?: Uri.EMPTY)
 * QeenSDK.flush()
 * QeenSDK.reset()
 * ```
 */
object QeenSDK {

    private const val TAG = "QeenSDK"

    private var provider: AnalyticsProvider? = null
    private var attribution: CampaignAttribution? = null
    private var debugLogging = false

    /**
     * Initialise the SDK. Call once, as early as possible (e.g. Application.onCreate).
     *
     * @param debug toggles branded `QeenSDK` logcat output. Off by default.
     * @param options advanced delivery settings, provisioned per workspace. Leave empty
     *   unless Qeen support has given you specific values.
     */
    fun configure(
        context: Context,
        apiKey: String,
        host: String,
        debug: Boolean = false,
        options: Map<String, Any> = emptyMap(),
    ) {
        debugLogging = debug
        val engine = PostHogProvider()
        engine.configure(context, apiKey, host, options)
        provider = engine
        attribution = CampaignAttribution()
        log("configured · host=$host")
    }

    fun identify(userId: String, traits: Map<String, Any>? = null) {
        val engine = provider ?: return warnNotConfigured("identify")
        log("identify · $userId")
        engine.identify(userId, traits)
    }

    fun track(event: String, properties: Map<String, Any>? = null) {
        val engine = provider ?: return warnNotConfigured("track")
        log("track · $event")
        engine.track(event, properties)
    }

    fun screen(name: String, properties: Map<String, Any>? = null) {
        val engine = provider ?: return warnNotConfigured("screen")
        log("screen · $name")
        engine.screen(name, properties)
    }

    /**
     * Feed every inbound deep link / app link here. Fires a "Deep Link Opened" event
     * carrying every query parameter on the link. Attribution (first/last-touch) is
     * derived server-side by Qeen.
     */
    fun handleDeepLink(uri: Uri) {
        val engine = provider ?: return warnNotConfigured("handleDeepLink")
        val attribution = attribution ?: return
        log("handleDeepLink · $uri")

        val eventProps = LinkedHashMap<String, Any>()
        eventProps["url"] = uri.toString()
        eventProps.putAll(attribution.allQueryParams(uri))
        engine.track("Deep Link Opened", eventProps)
    }

    fun reset() {
        val engine = provider ?: return warnNotConfigured("reset")
        log("reset")
        engine.reset()
    }

    fun flush() {
        val engine = provider ?: return warnNotConfigured("flush")
        log("flush")
        engine.flush()
    }

    // --- internal ---

    internal fun log(message: String) {
        if (debugLogging) Log.d(TAG, message)
    }

    private fun warnNotConfigured(method: String) {
        Log.w(TAG, "$method ignored — configure() has not been called")
    }
}
