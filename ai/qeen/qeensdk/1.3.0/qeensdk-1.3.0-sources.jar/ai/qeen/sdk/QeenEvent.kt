package ai.qeen.sdk

/**
 * Typed event surface for QeenSDK (added in 1.3.0).
 *
 * Design rules:
 *  1. Every monetary amount is a [Money] — an amount cannot exist without a currency.
 *  2. Product lines are always [LineItem]; the same type is used for cart, checkout,
 *     order and refund so CAPI payloads are built from one shape.
 *  3. [Custom] is the escape hatch for anything off-list. It cannot impersonate a
 *     first-class event — see [RESERVED_EVENT_NAMES] and [wireName].
 *
 * The legacy [QeenSDK.track] (freeform name + property map) is unchanged. These typed
 * events are dispatched through the same engine using the documented wire keys.
 */
sealed class QeenEvent(val name: String) {

    // ------------------------------------------------------------------
    // Product
    // ------------------------------------------------------------------

    data class ProductViewed(
        val item: LineItem,                       // required
    ) : QeenEvent("product_viewed")

    // ------------------------------------------------------------------
    // Cart
    // ------------------------------------------------------------------

    data class AddToCart(
        val cartId: String,                       // required
        val item: LineItem,                       // required
        val value: Money? = null,                 // cart total after the add
        val itemCount: Int? = null,
    ) : QeenEvent("add_to_cart")

    data class CartUpdated(
        val cartId: String,                       // required
        val value: Money? = null,
        val itemCount: Int? = null,
    ) : QeenEvent("cart_updated")

    // ------------------------------------------------------------------
    // Checkout
    // ------------------------------------------------------------------

    data class CheckoutStarted(
        val cartId: String,                       // required
        val value: Money? = null,
        val itemCount: Int? = null,
        val items: List<LineItem> = emptyList(),  // what's actually in the basket
        val email: String? = null,                // identity may be sent at checkout
        val phone: String? = null,
    ) : QeenEvent("checkout_started")

    data class OrderCompleted(
        val orderId: String,                      // required
        val cartId: String,                       // required — closes the loop
        val value: Money? = null,                 // wire key stays `order_value`
        val items: List<LineItem> = emptyList(),  // required in practice for CAPI
    ) : QeenEvent("order_completed")

    /**
     * Fire on refund or cancellation. Omitting these permanently inflates
     * reported ROAS, because the ad platform never learns the sale reversed.
     *
     * Partial refund: send only the refunded [items] and the refunded [value].
     * Full refund: send the original order total; [items] may be empty.
     */
    data class OrderRefunded(
        val orderId: String,                      // required — the join key
        val value: Money? = null,                 // amount refunded, not order total
        val items: List<LineItem> = emptyList(),  // populated for partial refunds
        val refundId: String? = null,             // dedupe key if a refund is retried
        val cartId: String? = null,
        val reason: String? = null,
    ) : QeenEvent("order_refunded")

    // ------------------------------------------------------------------
    // Identity
    // ------------------------------------------------------------------

    data class SignedIn(
        val method: String? = null,               // "email", "google", "apple", …
        val email: String? = null,
        val phone: String? = null,
    ) : QeenEvent("signed_in")

    data class SignedUp(
        val method: String? = null,
        val email: String? = null,
        val phone: String? = null,
    ) : QeenEvent("signed_up")

    // ------------------------------------------------------------------
    // Escape hatch
    // ------------------------------------------------------------------

    data class Custom(
        val eventName: String,
        val properties: Map<String, Any?> = emptyMap(),
    ) : QeenEvent(eventName)

    companion object {
        /** Names that only the typed cases above may emit. */
        val RESERVED_EVENT_NAMES: Set<String> = setOf(
            "product_viewed", "add_to_cart", "cart_updated", "checkout_started",
            "order_completed", "order_refunded", "signed_in", "signed_up",
        )
    }
}

// ----------------------------------------------------------------------
// Supporting types
// ----------------------------------------------------------------------

/**
 * A single product line. Reused across view, cart, checkout, order and refund
 * so one serializer builds every CAPI `contents` array.
 */
data class LineItem(
    val productId: String,                        // required — SKU or product id
    val quantity: Int = 1,
    val unitPrice: Money? = null,
    val name: String? = null,
    val category: String? = null,
    val variantId: String? = null,
)

/**
 * An amount and its currency, together. There is deliberately no way to
 * express an amount without one.
 */
data class Money(
    val amount: Double,
    val currency: Currency,
) {
    companion object {
        @JvmStatic fun of(amount: Double, currency: Currency) = Money(amount, currency)
        @JvmStatic fun usd(amount: Double) = Money(amount, Currency.USD)
        @JvmStatic fun jod(amount: Double) = Money(amount, Currency.JOD)
    }
}

/**
 * ISO-4217 currency. Constants cover the common cases; [of] accepts anything
 * else after validating the shape and normalising case, so "usd" and "USD"
 * can never arrive as two distinct currencies.
 */
class Currency private constructor(val code: String) {

    override fun equals(other: Any?) = other is Currency && other.code == code
    override fun hashCode() = code.hashCode()
    override fun toString() = code

    companion object {
        @JvmField val USD = Currency("USD")
        @JvmField val EUR = Currency("EUR")
        @JvmField val GBP = Currency("GBP")
        @JvmField val JOD = Currency("JOD")
        @JvmField val SAR = Currency("SAR")
        @JvmField val AED = Currency("AED")
        @JvmField val EGP = Currency("EGP")
        @JvmField val KWD = Currency("KWD")
        @JvmField val QAR = Currency("QAR")
        @JvmField val BHD = Currency("BHD")
        @JvmField val OMR = Currency("OMR")
        @JvmField val TRY = Currency("TRY")
        @JvmField val CAD = Currency("CAD")
        @JvmField val AUD = Currency("AUD")
        @JvmField val JPY = Currency("JPY")
        @JvmField val INR = Currency("INR")

        private val ISO_4217 = Regex("^[A-Za-z]{3}$")

        /**
         * Any other ISO-4217 code. Returns null rather than throwing on a
         * malformed code — an analytics SDK must never crash the host app.
         * Call sites should log via the `debug` flag when this returns null.
         */
        @JvmStatic
        fun of(code: String): Currency? =
            if (ISO_4217.matches(code)) Currency(code.uppercase()) else null
    }
}

// ----------------------------------------------------------------------
// Wire format
// ----------------------------------------------------------------------

/**
 * The event name actually sent on the wire. Identical to [QeenEvent.name] for every
 * first-class case; a [QeenEvent.Custom] that tries to reuse a reserved name is
 * de-collided with a `custom_` prefix so it can never impersonate a typed event.
 */
internal fun QeenEvent.wireName(): String = when (this) {
    is QeenEvent.Custom ->
        if (eventName in QeenEvent.RESERVED_EVENT_NAMES) "custom_$eventName" else eventName
    else -> name
}

/**
 * Maps the typed surface onto the documented JSON keys. `Money` flattens back into the
 * existing `price`/`value`/`order_value` + `currency` pairs.
 */
internal fun QeenEvent.properties(): Map<String, Any> = when (this) {

    is QeenEvent.ProductViewed -> item.flatten()

    is QeenEvent.AddToCart -> item.flatten() + mapOf(
        "cart_id" to cartId,
        "value" to value?.amount,
        "item_count" to itemCount,
        "currency" to (value?.currency ?: item.unitPrice?.currency)?.code,
    )

    is QeenEvent.CartUpdated -> mapOf(
        "cart_id" to cartId,
        "value" to value?.amount,
        "item_count" to itemCount,
        "currency" to value?.currency?.code,
    )

    is QeenEvent.CheckoutStarted -> mapOf(
        "cart_id" to cartId,
        "value" to value?.amount,
        "item_count" to itemCount,
        "currency" to value?.currency?.code,
        "items" to items.takeIf { it.isNotEmpty() }?.map { it.toContents() },
        "email" to email,
        "phone" to phone,
    )

    is QeenEvent.OrderCompleted -> mapOf(
        "order_id" to orderId,
        "cart_id" to cartId,
        "order_value" to value?.amount,
        "currency" to value?.currency?.code,
        "items" to items.takeIf { it.isNotEmpty() }?.map { it.toContents() },
    )

    is QeenEvent.OrderRefunded -> mapOf(
        "order_id" to orderId,
        "refund_id" to refundId,
        "cart_id" to cartId,
        "order_value" to value?.amount,
        "currency" to value?.currency?.code,
        "items" to items.takeIf { it.isNotEmpty() }?.map { it.toContents() },
        "reason" to reason,
    )

    is QeenEvent.SignedIn -> mapOf("method" to method, "email" to email, "phone" to phone)
    is QeenEvent.SignedUp -> mapOf("method" to method, "email" to email, "phone" to phone)

    is QeenEvent.Custom -> properties
}.filterValues { it != null }.mapValues { it.value as Any }

/** Top-level product keys, as documented for product_viewed / add_to_cart. */
private fun LineItem.flatten(): Map<String, Any?> = mapOf(
    "product_id" to productId,
    "name" to name,
    "price" to unitPrice?.amount,
    "quantity" to quantity,
    "category" to category,
    "variant_id" to variantId,
)

/** CAPI `contents` shape — amount only; currency is an order-level field. */
private fun LineItem.toContents(): Map<String, Any?> = mapOf(
    "id" to productId,
    "quantity" to quantity,
    "item_price" to unitPrice?.amount,
    "name" to name,
    "category" to category,
    "variant_id" to variantId,
).filterValues { it != null }
